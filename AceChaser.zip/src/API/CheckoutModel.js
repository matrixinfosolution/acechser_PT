import { BASE_URL } from "../MIS/Global";
import axios from "axios";
import React from "react";
import ReactDOM from "react-dom";
import Loader from "../Component/loader/Loader";

export const Saveorder = async (data) => { 
  ReactDOM.render(<Loader></Loader>, document.getElementById("root1"));
  let url = "saveorder";
  if (data.orderid > 0) {
    url = "updateorder";
  }
  let ret = {};
  var config = {
    method: "post",
    url: BASE_URL + url,
    headers: {
      "Content-Type": "application/json",
    },
    data: data,
  };
  await axios(config)
    .then(function (response) {
      ReactDOM.render(
        <Loader bal={false}></Loader>,
        document.getElementById("root1")
      );
      ret = response.data;
      if (ret.code == 200) {
        ret = { msg: ret.msg, code: 200, data: ret.data };
        return ret;
      } else if (ret.code == 400) {
        ret = { msg: ret.msg, code: 400 };
        return ret;
      } else {
        // alert(JSON.stringify(ret))
        ret = { msg: "something went wrong! please try again1 ", code: 500 };
        return ret;
      }
    })
    .catch(function (error) {
      ReactDOM.render(
        <Loader bal={false}></Loader>,
        document.getElementById("root1")
      );
      // alert(JSON.stringify(error))
      ret = { msg: "something went wrong! please try again1 ", code: 500 };
      return ret;
    });
  return ret;
};


export const savePayOrder = async (data) => { 
  ReactDOM.render(<Loader></Loader>, document.getElementById("root1"));
  let url = "payorder"; 
  let ret = {};
  var config = {
    method: "post",
    url: BASE_URL + url,
    headers: {
      "Content-Type": "application/json",
    },
    data: data,
  };
  await axios(config)
    .then(function (response) {
      ReactDOM.render(
        <Loader bal={false}></Loader>,
        document.getElementById("root1")
      );
      ret = response.data;
      if (ret.code == 200) {
        ret = { msg: ret.msg, code: 200, data: ret.data };
        return ret;
      } else if (ret.code == 400) {
        ret = { msg: ret.msg, code: 400 };
        return ret;
      } else {
        // alert(JSON.stringify(ret))
        ret = { msg: "something went wrong! please try again1 ", code: 500 };
        return ret;
      }
    })
    .catch(function (error) {
      ReactDOM.render(
        <Loader bal={false}></Loader>,
        document.getElementById("root1")
      );
      // alert(JSON.stringify(error))
      ret = { msg: "something went wrong! please try again1 ", code: 500 };
      return ret;
    });
  return ret;
};