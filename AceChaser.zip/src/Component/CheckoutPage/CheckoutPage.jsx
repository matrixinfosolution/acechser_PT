import { Grid } from "@mui/material";
import React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import img from "../../Assets/card.jpg";
import { Padding } from "@mui/icons-material";
import { Link } from "react-router-dom";
import "./CheckoutPage.css";

const CheckoutPage = () => {
  return (
    <Grid container spacing={2} className="paycon forscroll">
      <Grid item xs={12} md={12}>
        <h3>Credit/Debit/ATM Card</h3>
      </Grid>
      <Grid item xs={12} md={6}>
        <TextField
          size="small"
          id="outlined-case no-input"
          fullWidth
          label="Enter Card Number"
          // style={{ width: "85%" }}
          // value={mobileno}
          // inputProps={{ maxLength: 10 }}
          // onChange={async (e) => {
          //   let retdt = await onlynumeric(e);
          //   setMobileno(retdt);
          // }}
        />
      </Grid>
      <Grid item md={5} xs={5} sm={4}>
        <TextField
          id="date"
          size="small"
          fullWidth
          label="Valid thru"
          type="date"
          // value={bod}
          // defaultValue={bod}
          InputLabelProps={{
            shrink: true,
          }}
          // onChange={(e) => {
          //   setBod(e.target.value);
          // }}
          // onBlur={(e) => {
          //   calcAge(e);
          // }}
        />
      </Grid>
      <Grid item xs={4} md={4}>
        <TextField
          size="small"
          id="outlined-case no-input"
          fullWidth
          label="CCV"
          // style={{ width: "40%" }}
          // value={mobileno}
          // inputProps={{ maxLength: 10 }}
          // onChange={async (e) => {
          //   let retdt = await onlynumeric(e);
          //   setMobileno(retdt);
          // }}
        />
      </Grid>
      <Grid item xs={7} md={7}>
        <button
          style={{
            width: "180px",
            padding: "10px 10px",
            float: "right",
            backgroundColor: "#BAFF39",
            color: "white",
            cursor: "pointer",
            border: "none",
            fontSize: "18px",
            margin: "20px",
          }}
          onClick={() => {
            window.location = "/myorder";
          }}
        >
          PAY ₹10.00
        </button>
      </Grid>
      <Grid
        item
        xs={12}
        md={12}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <span>Add and secure your card as per RBI guidelines</span>
      </Grid>
    </Grid>
  );
};

export default CheckoutPage;
