import { Grid, Paper } from "@mui/material";
import { Box, padding } from "@mui/system";
import React from "react";
import LockIcon from "@mui/icons-material/Lock";
import VisibilityIcon from "@mui/icons-material/Visibility";
import Visibility from "@mui/icons-material/Visibility";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import HourglassBottomIcon from "@mui/icons-material/HourglassBottom";
const AnalyticsDashboard = () => {
  return (
    <div className="forscroll">
      <Grid container spacing={1} sx={{ padding: "10px" }}>
        <Grid item xs={12} md={12} sx={{}}>
          {/* <Paper elevation={"0.8px"}>
                        <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                            <span>Analyatics Audiance Home</span>
                            <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                                june 21 2021-jul 21 2021
                            </Box>
                        </Box>

                    </Paper> */}
        </Grid>
        <Grid item md={3} xs={6}>
          <Paper elevation={4}>
            <Box
              sx={{ display: "flex", flexDirection: "column", padding: "10px" }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <span>session</span>
                <LockIcon />
              </Box>
              <h1>
                1,350 <sub style={{ fontSize: "14px" }}>143%</sub>
              </h1>
              <p>vs previous month</p>
            </Box>
          </Paper>
        </Grid>
        <Grid item md={3} xs={6}>
          <Paper elevation={4}>
            <Box
              sx={{ display: "flex", flexDirection: "column", padding: "10px" }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <span>Page view</span>
                <Visibility />
              </Box>
              <h1>
                20,174 <sub style={{ fontSize: "14px" }}>20%</sub>
              </h1>
              <p>vs previous month</p>
            </Box>
          </Paper>
        </Grid>
        <Grid item md={3} xs={6}>
          <Paper elevation={4}>
            <Box
              sx={{ display: "flex", flexDirection: "column", padding: "10px" }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <span>user</span>
                <AccountCircleIcon />
              </Box>
              <h1>
                14,318 <sub style={{ fontSize: "14px" }}>53%</sub>
              </h1>
              <p>vs previous month</p>
            </Box>
          </Paper>
        </Grid>
        <Grid item md={3} xs={6}>
          <Paper elevation={4}>
            <Box
              sx={{ display: "flex", flexDirection: "column", padding: "10px" }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <span>Website Bounces(Avg</span>
                <HourglassBottomIcon />
              </Box>
              <h1>
                18,421<sub style={{ fontSize: "14px" }}>82%</sub>
              </h1>
              <p>vs previous month</p>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={2}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                padding: "8px",
                justifyContent: "space-between",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                }}
              >
                <span>Audiance Material</span>
              </Box>
              <Box>
                <h1>
                  974<sub style={{ fontSize: "14px" }}>56%</sub>
                </h1>
                <h4>Avg session</h4>
              </Box>
              <Box>
                <h1>
                  1,218<sub style={{ fontSize: "14px" }}>43%</sub>
                </h1>
                <h4>Conversion Rate</h4>
              </Box>
              <Box>
                <h1>
                  10,317<sub style={{ fontSize: "14px" }}>32%</sub>
                </h1>
                <h4>Avg session Duration</h4>
              </Box>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={2}>
            <Box
              sx={{ display: "flex", flexDirection: "column", padding: "10px" }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <span>Audiance Session by country</span>
              </Box>
            </Box>
          </Paper>
        </Grid>
        {/* <Grid item xs={12} md={4}>
                    <Paper elevation={3}>
                        <Box>
                            <span>Audiance Session by trafic chanel</span>
                            <div class="spinner_wrapper">
                                <div class="spinner">
                                    <div class="inner_spin">
                                    </div>
                                    <span class="fullie"><img src="http://lorempixel.com/600/600" /></span>
                                </div>

                                <div class="spinner">
                                    <div class="inner_spin">
                                    </div>
                                    <span class="fullie"><img src="http://lorempixel.com/600/600/" /></span>
                                </div>

                                <div class="spinner">
                                    <div class="inner_spin level">
                                    </div>
                                    <span class="fullie"><img src="http://lorempixel.com/600/600" /></span>
                                </div>
                            </div>
                        </Box>
                    </Paper>
                </Grid> */}
        <Grid item xs={12} md={4}>
          <Paper elevation={3}>
            <Box>
              <span>Average Session duration and bounce rate</span>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper elevation={3}>
            <Box>
              <span>Analyticas session by Device Type</span>
            </Box>
            <Box>
              <h1>
                5,140<sub style={{ fontSize: "14px" }}>180%</sub>
              </h1>
            </Box>
            <div
              style={{
                backgroundColor: "greenyellow",
                border: "1px solid",
                color: "white",
                padding: "10px",
                display: "flex",
                justifyContent: "space-between",
                textAlign: "center",
              }}
            >
              67%
              <div
                style={{
                  backgroundColor: "black",
                  color: "white",
                  padding: "10px",
                }}
              >
                25%
              </div>
            </div>
            <Box
              sx={{ display: "flex", flexDirection: "row", padding: "10px" }}
            >
              <span>Mobile</span>
              <h1>
                802,340{" "}
                <sub style={{ color: "greenyellow", fontSize: "14px" }}>
                  67%
                </sub>
              </h1>
              {/* <div style={{backgroundColor:"greenyellow", padding:"0.9px"}}></div> */}
              <Box>
                <span>Desktop</span>
                <h1>
                  34,712{" "}
                  <sub style={{ color: "greenyellow", fontSize: "14px" }}>
                    25%
                  </sub>
                </h1>
              </Box>
              <Box>
                <span>Tablets</span>
                <h1>
                  12,351
                  <sub style={{ color: "greenyellow", fontSize: "14px" }}>
                    8%
                  </sub>
                </h1>
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
};

export default AnalyticsDashboard;
