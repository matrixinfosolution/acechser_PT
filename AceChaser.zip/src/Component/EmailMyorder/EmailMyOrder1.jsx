import React from "react";
import barcode from "../../Assets/Barcode.png";
import barcode2 from "../../Assets/Barcode2.png";

const EmailMyorder1 = (props) => {
  const comp = {
    padding: "30px",
  };
  const head = {
    marginBottom: "10px",
    fontSize: "18px",
    fontWeight: "bold",
    backgroundColor: "04243f",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  };
  const nav = {
    backgroundColor: "aqua",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px",
  };
  const cont = {
    marginBottom: "10px",
    backgroundColor: "04243f",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: "-30%",
    gap: "20%",
  };
  const imgcomp = {
    height: "200px",
    width: "10%",
    marginTop: "10px",
  };

  return (
    <div style={comp} className="forscroll">
      <div style={head}>
        <div style={nav}>
          <span style={{ fontSize: "20px" }}>AceChaser</span>
          <p style={{ fontSize: "12px" }}>
            PRESENT THIS TICKET AT THE EVENT ENTRANCE PRINTED OR ON YOUR MOBILE
            DEVICE
          </p>
        </div>
      </div>
      <div style={cont}>
        <div>
          <h2>Chase The Ace Test</h2>
          <p>
            <span style={{ fontWeight: "bold" }}> DK Communittee Center</span>
            <br />
            <span>
              57 Church Hill Aventure <br />
              North Rustico PE
            </span>
          </p>
        </div>
        <div>
          <p>
            <span style={{ fontWeight: "bold" }}>
              {" "}
              SUN 08MAY2022 7:00PM <br />
              TICKET DETAILS: <br />
              General Seating <br />
              - <br />3 Ticket pack _ _ $10.00
            </span>
          </p>
        </div>
        <div style={imgcomp}>
          <span style={{ fontWeight: "bold" }}>
            <img
              style={{
                height: "100%",
                width: "100%",
                ObjectFit: "cover",
              }}
              src={barcode}
              alt=""
            />
            {/* <img
                    className="xsimg"
                    style={{
                      height: "60%",
                      width: "1000%",
                      ObjectFit: "cover",
                    }}
                    src={barcode2}
                    alt=""
                  /> */}
          </span>
        </div>
      </div>
    </div>
  );
};
