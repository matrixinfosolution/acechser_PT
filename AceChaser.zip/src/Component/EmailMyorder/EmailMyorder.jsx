import React from "react";
import { formatDatetime_dmy, getHourTime } from "../../MIS/Global";

const EmailMyorder = (props) => {
  // alert(JSON.stringify(props));
  if (props.data.length <= 0) {
    return;
  }
  const showdate = (showdate, type) => {
    let ret = "";
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const month_names_short = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    let weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    switch (type) {
      case "mname_full":
        break;
      case "mname_short":
        let month = new Intl.DateTimeFormat("defualt", {
          month: "short",
        }).format(new Date(showdate));
        ret = month;
        break;
      case "dayname_short":
        let dayname = new Intl.DateTimeFormat("defualt", {
          weekday: "short",
        }).format(new Date(showdate));
        ret = dayname;
        break;
      case "dayname_full":
        break;
      case "day":
        let day = new Date(showdate).getDate();
        if (day.toString().length <= 1) {
          day = `0${day}`;
        }
        ret = day;
        break;
      case "time":
        // let hours = new Date(showdate).getHours();
        // let minutes = new Date(showdate).getMinutes();
        let newTime = new Date(showdate).toLocaleTimeString("en-US");
        let hour = newTime.split(":")[0];
        let amPm = newTime.split(" ")[1];
        let seconds = newTime.split(":")[2].replace(amPm, "");
        let noSeconds = newTime.replace(":" + seconds, " ");
        if (parseInt(hour) < 9) {
          noSeconds = "0" + noSeconds;
        }
        ret = noSeconds;
        break;
      case "year":
        let year = new Date(showdate).getFullYear();
        ret = year;
        break;

      default:
        break;
    }

    // if (day.toString().length <= 1) {
    //   day = `0${day}`;
    // }

    // setShowtime(`${year}-${month}-${day} ${hours}:${minutes}`);
    return ret;
  };
  // alert(JSON.stringify(props));
  let month_name = showdate(props.data?.showtime, "mname_short");
  let day_name = showdate(props.data?.showtime, "dayname_short");
  let day = showdate(props.data?.showtime, "day");
  let year = showdate(props.data?.showtime, "year");
  let time = showdate(props.data?.showtime, "time");
  const comp = {
    padding: "30px",
  };
  const head = {
    marginBottom: "10px",
    fontSize: "18px",
    fontWeight: "bold",
    backgroundColor: "04243f",
    width: "100%",
    // display: 'flex',
    // justifyContent: 'space-between',
    alignItems: "center",
  };
  const nav = {
    backgroundColor: "#abe09f",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    flexDirection: "column",
    alignItems: "center",
    padding: "10px",
    gap: "20px",
  };
  const cont = {
    marginBottom: "10px",
    backgroundColor: "04243f",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: "-30%",
    gap: "20%",
  };
  const imgcomp = {
    height: "200px",
    width: "10%",
    marginTop: "10px",
    display: "none",
  };

  return (
    <div style={comp} className="forscroll">
      <div style={{ backgroundColor: "#baff39", padding: "10px" }}>
        <div style={{ fontSize: "22px" }}>AceChaser.com</div>
        {/* <br /> */}
        {/* <div style={{ fontSize: "12px" }}>
          PRESENT THIS TICKET AT THE EVENT ENTRANCE PRINTED OR ON YOUR MOBILE
          DEVICE
        </div> */}
      </div>
      <div></div>
      <p style={{ fontWeight: "bold" }}>Order No. #{props.data?.orderno}</p>
      <div style={cont}>
        <div style={{ width: "70%" }}>
          {/* <h3>{props.data?.vendernm}</h3> */}
          <h2>{props.data?.shownm}</h2>
          <p>
            <span style={{ fontWeight: "bold" }}>
              {" "}
              {props.data?.fname} {props.data?.lname}
            </span>
            <br />
            <span>
              {/* {props.data?.vendernm},{props.data?.eventnm}
              <br /> */}
              {props.data?.venuname}
            </span>
          </p>
        </div>
        <div>
          <p>
            <span style={{ fontWeight: "bold" }}>Draw Date:</span>
            <br />
            <span style={{ fontWeight: "bold" }}>
              {" "}
              {/* {day_name.toUpperCase()} {day} {month_name.toUpperCase()} {year} */}
              `${formatDatetime_dmy(props.data?.showtime,"dd")}/${formatDatetime_dmy(props.data?.showtime,"mm")}/${formatDatetime_dmy(props.data?.showtime,"yyyy")}                
              `
              <br />
              <span style={{ fontWeight: "bold" }}>Draw Time:</span>
              {/* {time} */}
              `${getHourTime(props.data?.showtime,12)}`
              <br />
              {/* SUN 08MAY2022 7:00PM <br /> */}
              {/* TICKET DETAILS: <br />
              General Seating <br /> */}
              {/* - <br /> */}
              {props.data?.qty} Ticket pack _ _ $
              {Number(props.data?.payment).toFixed(2)}
            </span>
          </p>
        </div>
        <div style={imgcomp}>
          <span style={{ fontWeight: "bold" }}>
            <img
              style={{
                height: "100%",
                width: "100%",
                ObjectFit: "cover",
              }}
              // src={barcode}
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGUAAAGQCAMAAACAil7jAAAAgVBMVEX///8AAABycnLo6Ojy8vLr6+upqan4+Pjc3Nz7+/vh4eFJSUnExMR4eHjLy8uJiYnV1dV+fn5lZWW4uLhaWlqVlZWjo6NTU1Obm5s5OTmPj4++vr6ysrI+Pj5CQkLd3d0jIyMrKytqamonJycODg4zMzMVFRVOTk4UFBQcHByDg4NEVjVtAAAJo0lEQVR4nO2dbZequg6AG6kiCAj4rojgyzj6/3/gaVIEZu85l7WvTbfjIV9GcS2eaUPbNEmDAMMyEN+JRUoyNSDbeQdl+O1Pfyqjl6Cs5iZk8xLa7yk9hZvif/vTn8qyg+JYodhpS0/5U4ot7XvPSyfFzqi0Q9ku18/LMu2gvJN1cdmYkOIltN9Tego3xc6oNLO+dFFGOwMShC+hFzuUyPGfF2fbQbGj/XhoQOTiJfTSU3oKN+UYGpDk2kGxs768016sp/wpxc76shiZkONLjH07lLErnxd33UF5A8+V71iguAAWKNIKpWkLp/abthhexeQvY4hpVKZWKAu8cyVeTblvDciiiYvFysBn1wv+/yN+ighh97jqwrmiTFbX52V1aShuawQ6Q6szfz4xIZcOCoNt6Y3X9yRZDlkpWVn14KKh3BcGZN2KI4fqnnuA1am6wKL9jLrnCBd3CrBkorgbCBC2Uf2lJhvJM/PLahrLIBVejo3hpASKop6JCc9aqSgRXhjAVBkXbCvyAC6O8EZ0Y4eN4nzAeZ4DrAWuNWcu68JZqY8FPsOKsuWzLuIo0jOKG7m1nWxAvC472fCo7Cn/B2X9CcWMPs3Y7DFBiwA+wkJM2SjqaQuGA20uSS6Ke4GZbkXUtvnnx/R5OeYPivr3PWxSCKXDavPrK6ma+l1GypiuyAmsG2t8kBiQe+PrO8Jcg/0CdmzP2BjgkhEmhjPfeAngoZoZ8FGEHEWVtvhG5W/SUzopMorUMu8fN5OspkRD53kZtmJJQQFw3g0pryARRq2LZmeh9siTHIoUJlFGU6Zui4GmtNuSYgMSgJODT3LIoxdJvTM80zIWQcFGwRadyFoe1qNyOTMgu/AXSkE2qzTsuWrP/NiK8OR+aYtpO3kOm/rqDm5MlJneTaJ4V7zEQlHL2GNKVh0WsPktZXMVNzFMlF+EKHaib3MD5lia5h0Uw2O/p/SUv0Q5eAb2+8JOXKxr7O9iAzKevoRe7FBmkQm5d1BY4mL43H6hMKxiuxCN5HLhMlL88qGnT5+NokyK41DZ4QO8NOSihPRHbWFj50abcg6KrO44UOa+DsQRhclDEmA7QtxlEMVMLKlsUaTGHhFVsMUsFvpP1rbGDVOw77Z+MIG9i7skNq9CQp+LMX3cs82WwbW8TOmhCj6iN5z57VB+bEZ3vJ58wHk1a1GywIBESUORdU7EZFhTTOtFbmASbdX0r8Abl4uyhZXuQV/N/uGDEhzGz4tfZ3S7N512kcJdbffhwOa7oAs7jIqmdfQtNpA+1sofe/j5Z0iZwYVp5i+A/IhXDFjyzfxKQzPhHOEmye9XUdYmUhSzVo7iRCMx/p5AwTb2l2eA+QE/ZRjxIco7Zaj2lP9NcXDWOvBm3cTV1F8MDjXFSA582MqBRzf5Zr/fY+rSSDCNfdV3U9KCFw8aP79hipr5l3U/JnWmCldUFIUth8QOxS0pR0VLCDnTeFF9l9AT7OETHXGNSnyST2VZ4m4cFzQeioiPn3TnU9LsxDl8F0M6qVZ54okSGTj61n32zfCotESJEt1T420yjbko3kYn21IXwpqJInXisHoa0ixlmy31DCP1pB+iA4OJ4qOVPEE7NmazLa84889oT9GKV4YmKh1NVzVFzWOuCPQGyefKhxHeBXLXu5FelrVejFsXY4AyUDuNzAvO9TNmvtJRpD5elK285xsvKE56w69FSuFRLoriRFEUt60+FkpbesoLU97ptODMRFws7ory2NGLHYqdHnuD04I95cUpdjzw6GZ4Xk5tShxVZ+zciC3+csA8n5S2Fws2C1bt8S/K0rwiJmOjhHB1xe6sN/9clCqjO6DTYmyZ9g8PyQx9vewUNYJuQ7Yecwt9XgzTU+dsmfa4ba1GSwp3rqxO4ZWAEVdBseSaYrzSkRxgLieKw5hprziP/JEoZMoc/l3oJzveHkuVjiRXpaOhK6Tk1oujtuHwwTT263PnIRRbxnnsi7BRyowiclsoR1wULwXIyS7yYSL4xn6kpq+pi56SXNR548YpNHhOO9WWXLgeV5QHlZOo++7QyS9Yrb4YHWYtCpcFm5UYEOemCBnHFigPeTuK+fXFHS31ETsh8XACUYxnEeAJOzhTF4VsM0wMMJ8C3LCP+HLh5ugWd0rI3bbNbz5TBVvhF/iN88QQXYjPMGpRDGcQSXTzVw9BzGbze/tHtHoEOWu+5Ui3ZgppTTGepYYnuHVrUmDbWeAZ7qv+IC9WqjY5o9Ebzsk/nOJFvoiYMrobcdq25WRlQurqQDJ/XJrA5+rn2/zBGB3ZM9jwRXjV3q+gElS8Nr+jbIC5r23+y5XP5o9KjIf6bTuZgUIP9mXJTlGbWPhi83PFLA4rKE1TvvNduK2zPHZOP/Ho5e9Q7Jyws+O5snPy0Y5eekpP4abYOVnf1+j++5R4u42EGC63iyY7nSWnF6akqKZao2nKDiCh9RkWg+asqOn1hY7XoD0mhbjjJd0o45Vb1NiQH5QAHde1Bw1Kyw9z+qU+jHmKMsO8G8VGm3xLw9WBdMW2AOgoMvkXiGJa+0v4CAJMXUij7IzFdHVbDFdt8qiS3mpAN08F18zvLjabhStmq82E8qF5KL8K/WR4vPwLxY5tybSKebtRVbiNRS8Rlevb0YWLw0SR8CloVO7v4ScUj7iY4aqAeh47UWayzGHEoxeiRNX2OGOsoIt3T+gqWwXdiqJrKbJVzqcb76phyFYZDCmur08iq0eNqTJY7YXDxoQ4Kdffnpff6vNPXOqwx/qyGC2fl+/fAOIW6Io3N+q1/PX9i53KxpYqHY2Z/DBytRApVzbU4ZG7tIPN4cf7xs85vZ7zAucNI6Uq0exw+saxdnKOaz/lw/Bl3MUlYBF4pMwCxrGfqS/BFw+88TcaoOB7Bjb8WTfCV9wNOwWrXW0bip23ZnBo/3eK4RhfI9JxGop5vQRhqDb7o5va8LHV7NL1lKYRwO1MTxkLRY3INcb54C4cKkPFQfFyvLNCXenqis3qwxBSQac4Y653QNR+mFjwZt3gqYSC7iu5ckhc3VcBFSTw2daXsKWEJT7KLJRDUw1YftTVgUxTRHZ9qFqfs+ahtMRHVy87heTtKHbexmhnZ/FTYxY9xQTFTvTNztt+7Yx9O5QfW0fxG8oyMyCzwUvoxQ7Fztvk+9PoPYWbYmceszMq7VDC6f15aVU6+p5iRy92KEYqHaX7l9B+T+kp3BRfeM/Li1Q6MpKfHP+X3gDSU/7LlOnagCzTDso7WRdGKh3lpw6KHe2brwn5HeWdtG+k7uh23kGxo31uyj8EfM0iemTkgQAAAABJRU5ErkJggg=="
              alt=""
            />
           
          </span>
        </div>
      </div>
      <div >
          <span style={{ fontSize: "12px", fontWeight: "bold" }}>
            Description:
          </span>
          <span style={{ fontSize: "12px" }}>
            {props.data?.desctext}
          </span>
        </div>
      <div>
        <span style={{ fontSize: "12px", fontWeight: "bold" }}>Rules:</span>
        <span style={{ fontSize: "12px" }}>
          All tickets must be purchased within the province of Prince Edward
          Island. When you purchase a ticket your IP address is recorded to be
          provided to the draw committee. In order to claim a cash prize, the
          winning ticket IP address will be validated
        </span>
      </div>
      <div>
         <div style={{ fontSize: "32px", color: "#BAFF39",width:"100%" }}>
          How AceChaser.com works
        </div>
        <div style={{width:"100%"}}>
          When you buy your tickets online AceChaser.com will send on your email
          with an Order Number on it. Depending on the committee, AceChaser.com
          will stop selling online a few hours before the draw time.
        </div>
        <div>
          Once the sales are stopped - I will run a report and send it to the
          committee with the following information:
        </div>
        <div>
          <p>* Order Number</p>
          <p>* First and Last Name</p>
          <p>* Email Address</p>
          <p>* Phone Number</p>
          <p>* Number of Tickets purchased</p>
        </div>
        <div>
          The committee will then assign a 50/50 ticket number to each ticket
          purchased online-then they put the other half of the 50/50 ticket in
          the drum for the draw
        </div>
        <div>
          If they draw out your number-committee will contact you with the good
          news!
        </div>
        <div>
          {" "}
          Do yoy still have questions? Click on{" "}
          <a href={`${window.location.protocol}//${window.location.host}/contact`} style={{ color: "#99e6ff" }}>
            Contact Us
          </a>{" "}
          and send us an email
        </div>
      </div>
    </div>
  );
};

export default EmailMyorder;
