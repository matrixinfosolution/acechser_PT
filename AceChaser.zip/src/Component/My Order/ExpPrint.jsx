import React, { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';
import EmailMyorder from '../EmailMyorder/EmailMyorder';
 
const ExpPrint = () => {
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () =>{ return(<h1>Welocme</h1>)},
  });

  return (
    <div>
      <EmailMyorder ref={componentRef} />
      <button onClick={handlePrint}>Print this out!</button>
    </div>
  );
};

export default ExpPrint
