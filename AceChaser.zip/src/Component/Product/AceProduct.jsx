import { Grid, Link } from '@mui/material'
import React from 'react'
import style from "./Product.module.css"
import { useNavigate } from 'react-router-dom';
 
const AceProduct = (props) => {
  const navigate = useNavigate();
  return (
    <>
        <Grid container spacing={2} sx={{padding:"20px"}}>
            <Grid item xs={12} md={12}>
                <div className={style.cardcontainer}>
                    <div className={style.cardimgcon}>
                    <img src={props?.data?.img} className={style.cardimg} />
                    </div>
                    <div className={style.ycontainer}>
                  <div className={style.subcon}>
                    <span className={style.subcontsp}>{props?.data?.showname}</span>
                    {/* <span className={style.overfolwtxt}>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam facere modi voluptas, dicta natus similique deleniti! Maxime cum, distinctio sit expedita deleniti alias, impedit sunt explicabo facere beatae temporibus suscipit?
                    </span> */}
                  </div>

                  <div className={style.datecon}>
                    <span>
                      {props?.data?.timedet}
                    </span>
                    {/* <span style={{ paddingLeft: "15px" }}>12:30</span> */}
                  </div>
                  {/* <Link className={style.lnk}> */}
                    <div 
                      style={{
                        height: "35px",
                        width: "100%",
                        backgroundColor: "#BAFF39",
                        color: "black",
                        justifyContent: "end",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        cursor: "pointer",
                      }}
                      onClick={() => {
                        props?.data?.getticket_dispatch({ type: "add", data: props?.data?.row });
                        navigate("/cartdetail");
                      }}
                    >
                      GET TICKETS
                    </div>
                  {/* </Link> */}
                </div>
                </div>
            </Grid>
        </Grid>
    </>
  )
}

export default AceProduct