import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import ContactusComp from "../../Component/ContactUs/ContactusComp";
import Cart from "../../Component/CartPage/Cart";
import CardDetail from "../../Component/CardDetail/CardDetail";
import NewtestProduct from "../../Component/Product/NewtestProduct";

const AllProductScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <NewtestProduct />
      </div>
    </div>
  );
};

export default AllProductScreen;
