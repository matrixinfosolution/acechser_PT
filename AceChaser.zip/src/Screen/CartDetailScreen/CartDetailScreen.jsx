import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import ContactusComp from "../../Component/ContactUs/ContactusComp";
import Cart from "../../Component/CartPage/Cart";
import CardDetail from "../../Component/CardDetail/CardDetail";

const CartDetailScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <CardDetail />
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default CartDetailScreen;
