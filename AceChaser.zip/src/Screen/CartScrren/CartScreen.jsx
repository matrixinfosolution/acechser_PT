import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import ContactusComp from "../../Component/ContactUs/ContactusComp";
import Cart from "../../Component/CartPage/Cart";

const CartScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <Cart />
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default CartScreen;
