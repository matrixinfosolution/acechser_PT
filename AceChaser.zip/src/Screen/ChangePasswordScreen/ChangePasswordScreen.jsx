import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import ChangePswComp from "../../Component/ChangePassword/ChangePswComp";

const ChangePasswordScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <ChangePswComp />
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default ChangePasswordScreen;
