import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import MyOrderHistory from "../../Component/My Order/MyOrderHistory";

const MyOrderHistoryScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <MyOrderHistory />
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default MyOrderHistoryScreen;
