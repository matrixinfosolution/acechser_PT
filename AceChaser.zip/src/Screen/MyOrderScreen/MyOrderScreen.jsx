import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import MyOrder from "../../Component/My Order/MyOrder";

const MyOrderScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <MyOrder />
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default MyOrderScreen;
