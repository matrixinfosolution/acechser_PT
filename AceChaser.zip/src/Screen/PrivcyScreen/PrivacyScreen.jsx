import React from "react";
import NavbarComp from "../../Component/Navbar/NavbarComp";
import FooterComp from "../../Component/Footer/FooterComp";
import Policy from "../../Component/ChangePassword/Policy";

const PrivacyScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <Policy />
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default PrivacyScreen;
