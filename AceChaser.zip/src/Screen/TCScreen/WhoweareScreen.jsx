import React from "react";
import Whoweare from "../../Component/ChangePassword/Whoweare";
import FooterComp from "../../Component/Footer/FooterComp";
import NavbarComp from "../../Component/Navbar/NavbarComp";

const WhoweareScreen = () => {
  return (
    <div>
      <div className="navbar">
        <NavbarComp />
      </div>
      <div className="comp">
        <Whoweare></Whoweare>
      </div>
      <div className="footer">
        <FooterComp />
      </div>
    </div>
  );
};

export default WhoweareScreen;
